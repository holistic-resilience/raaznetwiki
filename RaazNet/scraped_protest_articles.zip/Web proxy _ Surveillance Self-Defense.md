[Skip to main content](https://ssd.eff.org/vi/glossary/web-proxy#main-content)

- [Về](https://ssd.eff.org/vi/pages/about-surveillance-self-defense)
- [Ngôn ngữ](https://ssd.eff.org/vi/glossary/web-proxy#)  - [English](https://ssd.eff.org/glossary/web-based-proxy)
  - [አማርኛ](https://ssd.eff.org/am/glossary/4dfb2bd7-8529-469c-9993-c4a85b951276)
  - [العربية](https://ssd.eff.org/ar/glossary/313c401d-3c39-4dbb-8491-a6fbd7a6a8f3)
  - [Español](https://ssd.eff.org/es/glossary/proxy-basada-en-la-red)
  - [Français](https://ssd.eff.org/fr/glossary/mandataire-web)
  - [Русский](https://ssd.eff.org/ru/glossary/cf17872e-046d-463e-ad12-18ae35183c9b)
  - [Türkçe](https://ssd.eff.org/tr/glossary/web-tabanli-vekil-sunucu)
  - [Tiếng Việt](https://ssd.eff.org/vi/glossary/web-proxy)
  - [Português](https://ssd.eff.org/pt-br/glossary/web-based-proxy-e09b8a7c-826e-4d87-8615-8b969fcfe3df)
  - [Mandarin](https://ssd.eff.org/zh-hans/glossary/web-proxy)
  - [Burmese](https://ssd.eff.org/my/glossary/web-proxy)
  - [پښتو](https://ssd.eff.org/ps/glossary/web-proxy)
  - [ภาษาไทย](https://ssd.eff.org/th/glossary/551a5928-3cca-4178-a144-906e9ae3a289)
  - [اردو](https://ssd.eff.org/ur/glossary/0179035e-6c4c-4f15-9e42-7ac3ca31fcc7)
  - [More Translations](https://ssd.eff.org/en/other-translations)
- [Index](https://ssd.eff.org/#index)
- KeywordsTìm kiếm

[×](https://ssd.eff.org/vi/glossary/web-proxy#)

# Web proxy

Một trang web cho phép người sử dụng truy cập các trang web khác bị chặn hoặc kiểm duyệt . Nói chung, trang web proxy sẽ cho phép bạn gõ một địa chỉ web (hoặc URL) vào một trang web, và sau đó hiển thị lại địa chỉ web trên trang web proxy. Việc sử dụng nó dễ dàng hơn so với hầu hết các dịch vụ vượt qua kiểm duyệt khác.

- [Copyright (CC BY)](https://www.eff.org/copyright)
- [Riêng Tư](https://www.eff.org/policy)