[Skip to main content](https://ssd.eff.org/module/mobile-phones-spying-mobile-communications#main-content)

- [About](https://ssd.eff.org/pages/about-surveillance-self-defense)
- [Language](https://ssd.eff.org/module/mobile-phones-spying-mobile-communications#)  - [English](https://ssd.eff.org/module/mobile-phones-spying-mobile-communications)
  - [አማርኛ](https://ssd.eff.org/am/module/mobile-phones-spying-mobile-communications)
  - [العربية](https://ssd.eff.org/ar/module/e07e6fe2-203b-4380-9f96-548b365c8fcb)
  - [Español](https://ssd.eff.org/es/module/tel%C3%A9fonos-m%C3%B3viles-espiando-las-comunicaciones-m%C3%B3viles)
  - [Français](https://ssd.eff.org/fr/module/telephones-portables-espionnage-des-communications-mobiles)
  - [Русский](https://ssd.eff.org/ru/module/%D0%BC%D0%BE%D0%B1%D0%B8%D0%BB%D1%8C%D0%BD%D1%8B%D0%B5-%D1%82%D0%B5%D0%BB%D0%B5%D1%84%D0%BE%D0%BD%D1%8B-%D1%81%D0%BB%D0%B5%D0%B6%D0%BA%D0%B0-%D0%B7%D0%B0-%D0%BC%D0%BE%D0%B1%D0%B8%D0%BB%D1%8C%D0%BD%D0%BE%D0%B9-%D1%81%D0%B2%D1%8F%D0%B7%D1%8C%D1%8E)
  - [Türkçe](https://ssd.eff.org/tr/module/cep-telefonlar%C4%B1-mobil-haberle%C5%9Fme-takibi)
  - [Tiếng Việt](https://ssd.eff.org/vi/module/mobile-phones-spying-mobile-communications)
  - [Português](https://ssd.eff.org/pt-br/module/telefones-celulares-espionagem-de-comunicacoes-moveis)
  - [Mandarin](https://ssd.eff.org/zh-hans/module/e31e2e1c-043e-4f80-bb99-ba6a43b8020b)
  - [Burmese](https://ssd.eff.org/my/module/mobile-phones-spying-mobile-communications)
  - [پښتو](https://ssd.eff.org/ps/module/mobile-phones-spying-mobile-communications)
  - [ภาษาไทย](https://ssd.eff.org/th/module/mobile-phones-spying-mobile-communications)
  - [اردو](https://ssd.eff.org/ur/module/mobile-phones-spying-mobile-communications)
  - [More Translations](https://ssd.eff.org/en/other-translations)
- [Index](https://ssd.eff.org/#index)
- KeywordsSearch

[×](https://ssd.eff.org/module/mobile-phones-spying-mobile-communications#)

# Mobile Phones: Spying on Mobile Communications

**Last Reviewed**: November 05, 2024

## Spying on Mobile Communications [\#](https://ssd.eff.org/module/mobile-phones-spying-mobile-communications\#spying-on-mobile-communications)

Mobile phone networks were not originally designed to use technical means to protect subscribers' calls against eavesdropping. That meant that anybody with the right kind of radio receiver could listen in on the calls.

The situation is somewhat better today with [encryption ![](https://ssd.eff.org/assets/efforg/info-7ae1fb29e1e734b20023f3e3470316c82b84a7e4b9f1d1e2f49e399f1f8de2d3.png)](https://ssd.eff.org/glossary/encryption) technology. But many of these technologies have been poorly designed (sometimes deliberately, due to government pressure not to use strong encryption). They have been unevenly deployed, so they might be available on one carrier but not another, or in one country but not another, and have sometimes been implemented incorrectly. For example, in some countries carriers do not enable encryption at all, or they use obsolete technical standards. This means it is often still possible for someone with the [right kind of radio receiver](https://sls.eff.org/technologies/cell-site-simulators-imsi-catchers) to intercept calls and text messages as they're transmitted over the air. Law enforcement can also intercept your real-time communications with the aid of providers after obtaining special [wiretapping warrants](https://www.uscourts.gov/statistics-reports/analysis-reports/wiretap-reports), or obtain your stored communications from a provider with a [warrant](https://www.eff.org/deeplinks/2010/12/breaking-news-eff-victory-appeals-court-holds).

The safest practice is to assume that traditional calls and SMS text messages have not been secured against eavesdropping or recording. Even though the technical details vary significantly from place to place and system to system, the technical protections are often weak and can be bypassed in many situations.

**What you can do**: There is a solution here, though: [end-to-end encryption ![](https://ssd.eff.org/assets/efforg/info-7ae1fb29e1e734b20023f3e3470316c82b84a7e4b9f1d1e2f49e399f1f8de2d3.png)](https://ssd.eff.org/glossary/end-to-end-encryption). This type of [encryption wraps the content of your conversation](https://ssd.eff.org/module/communicating-others) in complex math so only you and the person you’re communicating with can read the messages. It’s good to use apps that support end-to-end encryption as often as possible. Some options include [Signal](https://ssd.eff.org/module/how-to-use-signal), [WhatsApp](https://ssd.eff.org/module/how-to-use-whatsapp), and Apple’s iMessage (but these conversations are only end-to-end encrypted when you’re chatting with other Apple users, signaled by the conversation bubbles being blue instead of green).

![An animation of two phones sending end-to-end encrypted text messages to each other. As the messages are passed from networks to the phones, the people in the middle only see that encrypted messages are being sent (but not the content of the messages).](https://ssd.eff.org/files/ssd/wysiwyg/pictures/745/content_encryption-types-emoji.gif)

- [Copyright (CC BY)](https://www.eff.org/copyright)
- [Privacy](https://www.eff.org/policy)