[Skip to main content](https://ssd.eff.org/module/how-use-whatsapp#main-content)

- [About](https://ssd.eff.org/pages/about-surveillance-self-defense)
- [Language](https://ssd.eff.org/module/how-use-whatsapp#)  - [English](https://ssd.eff.org/404?id=how-use-whatsapp)
  - [አማርኛ](https://ssd.eff.org/am/404?id=how-use-whatsapp)
  - [العربية](https://ssd.eff.org/ar/404?id=how-use-whatsapp)
  - [Español](https://ssd.eff.org/es/404?id=how-use-whatsapp)
  - [Français](https://ssd.eff.org/fr/404?id=how-use-whatsapp)
  - [Русский](https://ssd.eff.org/ru/404?id=how-use-whatsapp)
  - [Türkçe](https://ssd.eff.org/tr/404?id=how-use-whatsapp)
  - [Tiếng Việt](https://ssd.eff.org/vi/404?id=how-use-whatsapp)
  - [Português](https://ssd.eff.org/pt-br/404?id=how-use-whatsapp)
  - [Mandarin](https://ssd.eff.org/zh-hans/404?id=how-use-whatsapp)
  - [Burmese](https://ssd.eff.org/my/404?id=how-use-whatsapp)
  - [پښتو](https://ssd.eff.org/ps/404?id=how-use-whatsapp)
  - [ภาษาไทย](https://ssd.eff.org/th/404?id=how-use-whatsapp)
  - [اردو](https://ssd.eff.org/ur/404?id=how-use-whatsapp)
  - [More Translations](https://ssd.eff.org/en/other-translations)
- [Index](https://ssd.eff.org/#index)
- KeywordsSearch

[×](https://ssd.eff.org/module/how-use-whatsapp#)

# Oops! (404)

Page not found

- [Copyright (CC BY)](https://www.eff.org/copyright)
- [Privacy](https://www.eff.org/policy)